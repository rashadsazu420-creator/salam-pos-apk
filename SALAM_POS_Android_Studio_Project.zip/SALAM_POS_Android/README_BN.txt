SALAM COMPUTER AND GIFT SHOP — Shop POS Pro Android Studio Project (v2.0)

এই ZIP ফাইলটি Android Studio-তে খুলে Android APK তৈরি করার জন্য প্রস্তুত করা হয়েছে। এই পরিবেশে Android SDK/Gradle build tool না থাকায় তৈরি করা APK পরীক্ষা/কম্পাইল করা সম্ভব হয়নি; এটি Android Studio project, APK নয়।

ফিচার:
- ক্যাশ মেমো: পণ্য, পরিমাণ, দর, ছাড়, অতিরিক্ত চার্জ ও মোট
- কম্পিউটার কম্পোজ, প্রিন্ট, ফটোকপি ও অন্যান্য সার্ভিস
- মোবাইল রিচার্জের অপারেটর, নম্বর, পরিমাণ, Txn ID ও স্ট্যাটাস রেকর্ড
- DPDC বিলের টোকেন/গ্রাহক নম্বর, পরিমাণ ও স্ট্যাটাস রেকর্ড
- রসিদ দেখা, এই ডিভাইসে সংরক্ষণ, Android print dialog থেকে প্রিন্ট/PDF
- অফলাইনে লোকাল রসিদ ব্যবস্থাপনা

Android Studio দিয়ে APK বানানোর ধাপ:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP extract করুন। Android Studio > Open থেকে SALAM_POS_Android ফোল্ডার নির্বাচন করুন।
3. Gradle sync শেষ হতে দিন; প্রয়োজন হলে Android SDK Platform 35 ইনস্টল করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. সফল হলে app/build/outputs/apk/debug/app-debug.apk ফাইলটি ফোনে কপি করে ইনস্টল করুন।
6. ফোনে ইনস্টল করার সময় প্রয়োজন হলে Settings থেকে এই উৎসের app install অনুমতি দিন।

গুরুত্বপূর্ণ:
- এই সংস্করণ মোবাইল রিচার্জ বা DPDC-তে বাস্তব টাকা পাঠায় না; শুধু লেনদেনের তথ্য/রসিদ সংরক্ষণ করে। প্রকৃত লেনদেনের জন্য অনুমোদিত provider API, merchant account ও নিরাপদ server integration প্রয়োজন।
- রসিদ স্থানীয় WebView storage-এ থাকে। অ্যাপের ডেটা মুছে ফেললে বা অ্যাপ আনইনস্টল করলে হারাতে পারে; নিয়মিত PDF/প্রিন্ট ব্যাকআপ রাখুন।
- গ্রাহকের বাস্তব তথ্য ব্যবহারের আগে পরীক্ষা করুন।
- APK build এবং বিভিন্ন Android ফোনে পরীক্ষা এই পরিবেশে করা হয়নি।

দোকানের তথ্য:
SALAM COMPUTER AND GIFT SHOP
Munshibag, Madrasha Road, Kutubpur, Fatullah, Narayanganj-1421
01977779697 | rashad_sazu@yahoo.com | 01917013083
